#ifndef BALL_H
#define BALL_H
#define SCREEN_WIDTH 80
#define SCREEN_HEIGHT 24

#define BLOCK_H

struct Block {
    int x, y;
    bool alive;
};

void draw_blocks(const Block blocks[], int num_blocks);


struct Ball {
    int x, y;
    int dx, dy;
};

void draw_ball(const Ball& ball);
void move_ball(Ball& ball);

#define PADDLE_H

#define PADDLE_WIDTH 20

struct Paddle {
    int x, y;
};

void draw_paddle(const Paddle& paddle);
void handle_input(Paddle& paddle);

#endif
